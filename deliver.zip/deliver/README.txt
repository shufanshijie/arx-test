# ARX Service Delivery - Windows Instructions

This package allows you to run the ARX Service on Windows without installing Java.

## Contents

- `jre/` — Bundled Java Runtime Environment (JRE 17)
- `arx-service-1.0.0.jar` — Executable Spring Boot JAR
- `start.bat` — Windows startup script
- `README.txt` — This instruction file

## How to Run

1. Extract the entire `deliver` folder to your preferred location.
2. Double-click `start.bat` to start the service.
   - Alternatively, you can open a Command Prompt in this folder and run:
     ```
     start.bat
     ```
3. The service will start using the bundled JRE. **No need to install Java.**
4. By default, the service will be available at: [http://localhost:8080](http://localhost:8080)

## Notes
- The JRE in the `jre/` folder is only used by this service and does not affect other applications.
- To change the port, you can edit the `application.yml` inside the jar or modify the `start.bat` to add `--server.port=xxxx`.
- If you encounter any issues, please contact the delivery team.

## Example Directory Structure

```
deliver/
├── jre/
├── arx-service-1.0.0.jar
├── start.bat
└── README.txt
``` 